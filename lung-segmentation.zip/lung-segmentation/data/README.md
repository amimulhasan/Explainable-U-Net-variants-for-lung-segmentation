# Data directory

Place your chest X-ray images and lung masks here:

```
data/
├── images/     # e.g. patient001.png, patient002.png, ...
└── masks/      # e.g. patient001.png, patient002.png, ...
```

- Image and mask filenames should match (same stem).
- Supported extensions: `.png`, `.jpg`, `.jpeg`, `.bmp`, `.tif`, `.tiff`
- Masks should be binary (lung = white / foreground).

### Kaggle dataset example
Dataset: `amimulahasanrofik/chest-x-ray-segmentation`

On Kaggle the notebook will also look under:
- `/kaggle/input/datasets/amimulahasanrofik/chest-x-ray-segmentation/image`
- `/kaggle/input/datasets/amimulahasanrofik/chest-x-ray-segmentation/Masks`
